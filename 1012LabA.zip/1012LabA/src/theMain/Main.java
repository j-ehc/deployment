package theMain;

public static void Main() {
	
	public static void Add()
	
	{
		int a = 5;
		int b = 4;
		
		int result = a + b;
		return;		
		
	}
	
	public static void Subtract()
	
	{
		int a = 9;
		int b = 1;
		
		int result = a - b;
		return;
		
	}
	
	public static void Multiply()
	
	{
		int a = 1;
		int b = 7;
		
		int result = a * b;
		return;
		
	}
	
	public static void Divide()
	
	{
		int a = 12;
		int b = 2;
		
		int result = a / b;
		return;
		
	}

}