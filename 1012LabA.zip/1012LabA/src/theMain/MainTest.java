package theMain;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class MainTest {


	public class Add {

	@Test
	void addTest() {
		
		assertEquals(9, Main.Add.result);
		
		fail("Your addition is wrong");
	}
	
	
	@Test
	void subtTest() {
		
		assertEquals(8, Main.Subtract.result);
		
		fail("Your addition is wrong");
	}
	
	
	@Test
	void multTest() {
		
		assertEquals(7, Main.Multiply.result);
		
		fail("Your addition is wrong");
	}
	
	
	@Test
	void divTest() {
		
		assertEquals(6, Main.Divide.result);
		
		fail("Your addition is wrong");
	}

}
}